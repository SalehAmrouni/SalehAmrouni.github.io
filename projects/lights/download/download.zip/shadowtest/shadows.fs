#version 330
in vec3 fragPosition;
in vec3 fragNormal;
in vec4 fragPosLightSpace[2];

out vec4 finalColor;

uniform sampler2D shadowMap0;
uniform sampler2D shadowMap1;
uniform vec3 lightPos[2];
uniform vec3 lightColor[2];
uniform vec4 colDiffuse;

float CalculateShadow(vec4 fragPosLightSpace, sampler2D depthMap, vec3 normal, vec3 lightDir) {
    vec3 projCoords = fragPosLightSpace.xyz / fragPosLightSpace.w;
    projCoords = projCoords * 0.5 + 0.5;

    if (projCoords.z > 1.0 || projCoords.x < 0.0 || projCoords.x > 1.0 || projCoords.y < 0.0 || projCoords.y > 1.0) {
        return 0.0;
    }

    float currentDepth = projCoords.z;
    float bias = max(0.002 * (1.0 - dot(normal, lightDir)), 0.0005);

    // Single depth sample creates crisp, hard shadow edges
    float closestDepth = texture(depthMap, projCoords.xy).r;
    return (currentDepth - bias > closestDepth) ? 1.0 : 0.0;
}

void main() {
    vec3 normal = normalize(fragNormal);
    vec3 ambient = vec3(0.25);
    vec3 lighting = ambient;

    // Light 0
    vec3 lDir0 = normalize(lightPos[0] - fragPosition);
    float diff0 = max(dot(normal, lDir0), 0.0);
    float shadow0 = CalculateShadow(fragPosLightSpace[0], shadowMap0, normal, lDir0);
    lighting += (1.0 - shadow0) * (diff0 * lightColor[0]);

    // Light 1
    vec3 lDir1 = normalize(lightPos[1] - fragPosition);
    float diff1 = max(dot(normal, lDir1), 0.0);
    float shadow1 = CalculateShadow(fragPosLightSpace[1], shadowMap1, normal, lDir1);
    lighting += (1.0 - shadow1) * (diff1 * lightColor[1]);

    vec4 baseColor = (colDiffuse.a > 0.0) ? colDiffuse : vec4(0.1);
    finalColor = vec4(lighting * baseColor.rgb, baseColor.a);
}
