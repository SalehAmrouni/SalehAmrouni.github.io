#version 330
in vec3 vertexPosition;
in vec2 vertexTexCoord;
in vec3 vertexNormal;

uniform mat4 mvp;
uniform mat4 matModel;
uniform mat4 lightSpaceMatrix[2];

out vec3 fragPosition;
out vec3 fragNormal;
out vec4 fragPosLightSpace[2];

void main() {
    vec4 worldPos = matModel * vec4(vertexPosition, 1.0);
    fragPosition = vec3(worldPos);
    fragNormal = normalize(mat3(transpose(inverse(matModel))) * vertexNormal);

    fragPosLightSpace[0] = lightSpaceMatrix[0] * worldPos;
    fragPosLightSpace[1] = lightSpaceMatrix[1] * worldPos;

    gl_Position = mvp * vec4(vertexPosition, 1.0);
}
