#include <stddef.h>
#include "raylib.h"
#include "raymath.h"
#include "rlgl.h"

// Double resolution for finer pixel fidelity
#define SHADOWMAP_RES 2048 





typedef struct {
    Model plane;
    Model cube;
    Model sphere;
    Model cylinder;
} SceneModels;

RenderTexture2D LoadShadowMap(int width, int height) {
    RenderTexture2D target = { 0 };
    target.id = rlLoadFramebuffer();
    if (target.id > 0) {
        rlEnableFramebuffer(target.id);
        
        target.texture.id = rlLoadTexture(0, width, height, PIXELFORMAT_UNCOMPRESSED_R8G8B8A8, 1);
        target.texture.width = width;
        target.texture.height = height;
        target.texture.format = PIXELFORMAT_UNCOMPRESSED_R8G8B8A8;
        target.texture.mipmaps = 1;
        
        target.depth.id = rlLoadTextureDepth(width, height, 0);
        target.depth.width = width;
        target.depth.height = height;
        target.depth.format = PIXELFORMAT_UNCOMPRESSED_R32;
        target.depth.mipmaps = 1;
        
        rlFramebufferAttach(target.id, target.texture.id, RL_ATTACHMENT_COLOR_CHANNEL0, RL_ATTACHMENT_TEXTURE2D, 0);
        rlFramebufferAttach(target.id, target.depth.id, RL_ATTACHMENT_DEPTH, RL_ATTACHMENT_TEXTURE2D, 0);
        rlDisableFramebuffer();

        SetTextureFilter(target.depth, TEXTURE_FILTER_POINT);
        SetTextureWrap(target.depth, TEXTURE_WRAP_CLAMP);
    }
    return target;
}

void SetSceneShader(SceneModels *models, Shader shader) {
    models->plane.materials[0].shader = shader;
    models->cube.materials[0].shader = shader;
    models->sphere.materials[0].shader = shader;
    models->cylinder.materials[0].shader = shader;
}

void DrawScene(SceneModels models) {
    DrawModel(models.plane, (Vector3){ 0.0f, 0.0f, 0.0f }, 1.0f, GRAY);
    DrawModel(models.cube, (Vector3){ 0.0f, 1.0f, 0.0f }, 1.0f, BLUE);
    DrawModel(models.sphere, (Vector3){ -3.0f, 1.0f, 2.0f }, 1.0f, RED);
    DrawModel(models.cylinder, (Vector3){ 3.0f, 1.5f, -1.0f }, 1.0f, GREEN);
}

int main(void) {
    InitWindow(1280, 720, "Raylib - Multi-Light Shadows");

    Camera3D mainCam = { 0 };
    mainCam.position = (Vector3){ 0.0f, 10.0f, 12.0f };
    mainCam.target = (Vector3){ 0.0f, 0.0f, 0.0f };
    mainCam.up = (Vector3){ 0.0f, 1.0f, 0.0f };
    mainCam.fovy = 45.0f;
    mainCam.projection = CAMERA_PERSPECTIVE;

    SceneModels models = {
        .plane = LoadModelFromMesh(GenMeshPlane(20.0f, 20.0f, 1, 1)),
        .cube = LoadModelFromMesh(GenMeshCube(2.0f, 2.0f, 2.0f)),
        .sphere = LoadModelFromMesh(GenMeshSphere(1.0f, 16, 16)),
        .cylinder = LoadModelFromMesh(GenMeshCylinder(0.8f, 3.0f, 16))
    };

    Vector3 lightPos[2] = { { -6.0f, 8.0f, 4.0f }, { 6.0f, 10.0f, -2.0f } };
    Vector3 lightColor[2] = { { 1.0f, 0.9f, 0.7f }, { 0.4f, 0.6f, 1.0f } };

    RenderTexture2D shadowMaps[2] = {
        LoadShadowMap(SHADOWMAP_RES, SHADOWMAP_RES),
        LoadShadowMap(SHADOWMAP_RES, SHADOWMAP_RES)
    };

    Shader casterShader = LoadShader("caster.vs", "caster.fs");
    Shader shadowShader = LoadShader("shadows.vs", "shadows.fs");
    
    casterShader.locs[SHADER_LOC_MATRIX_MODEL] = GetShaderLocation(casterShader, "matModel");
    shadowShader.locs[SHADER_LOC_MATRIX_MODEL] = GetShaderLocation(shadowShader, "matModel");

    int lightPosLoc = GetShaderLocation(shadowShader, "lightPos");
    int lightColorLoc = GetShaderLocation(shadowShader, "lightColor");
    int lightMat0Loc = GetShaderLocation(shadowShader, "lightSpaceMatrix[0]");
    int lightMat1Loc = GetShaderLocation(shadowShader, "lightSpaceMatrix[1]");
    int map0Loc = GetShaderLocation(shadowShader, "shadowMap0");
    int map1Loc = GetShaderLocation(shadowShader, "shadowMap1");

    SetTargetFPS(60);

    while (!WindowShouldClose()) {
        UpdateCamera(&mainCam, CAMERA_ORBITAL);

        Matrix lightSpaceMat[2];

        // Pass 1: Render Shadow Maps using dedicated Depth Caster
        SetSceneShader(&models, casterShader);
        for (int i = 0; i < 2; i++) {
            Camera3D lightCam = { 0 };
            lightCam.position = lightPos[i];
            lightCam.target = (Vector3){ 0.0f, 0.0f, 0.0f };
            lightCam.up = (Vector3){ 0.0f, 1.0f, 0.0f };
            lightCam.fovy = 20.0f;
            lightCam.projection = CAMERA_ORTHOGRAPHIC;

            Matrix lightView = MatrixLookAt(lightPos[i], (Vector3){ 0.0f, 0.0f, 0.0f }, (Vector3){ 0.0f, 1.0f, 0.0f });
            // Inside Pass 1 loop:
			float rres = 16.0f; // Reduced from 24.0f to concentrate shadow map pixel density on the scene
			Matrix lightProj = MatrixOrtho(-rres/2.0f, rres/2.0f, -rres/2.0f, rres/2.0f, 1.0f, 50.0f);
            lightSpaceMat[i] = MatrixMultiply(lightView, lightProj);

            BeginTextureMode(shadowMaps[i]);
                ClearBackground(WHITE);
                BeginMode3D(lightCam);
                    rlSetMatrixProjection(lightProj);
                    DrawScene(models);
                EndMode3D();
            EndTextureMode();
        }

        // Pass 2: Render Main Scene with Shadow Shader
        SetSceneShader(&models, shadowShader);
        BeginDrawing();
            ClearBackground(DARKGRAY);
            
            BeginMode3D(mainCam);
                SetShaderValueV(shadowShader, lightPosLoc, lightPos, SHADER_UNIFORM_VEC3, 2);
                SetShaderValueV(shadowShader, lightColorLoc, lightColor, SHADER_UNIFORM_VEC3, 2);
                SetShaderValueMatrix(shadowShader, lightMat0Loc, lightSpaceMat[0]);
                SetShaderValueMatrix(shadowShader, lightMat1Loc, lightSpaceMat[1]);
                
                rlActiveTextureSlot(1);
                rlEnableTexture(shadowMaps[0].depth.id);
                SetShaderValue(shadowShader, map0Loc, (int[]){ 1 }, SHADER_UNIFORM_INT);

                rlActiveTextureSlot(2);
                rlEnableTexture(shadowMaps[1].depth.id);
                SetShaderValue(shadowShader, map1Loc, (int[]){ 2 }, SHADER_UNIFORM_INT);

                DrawScene(models);

                rlActiveTextureSlot(0);

                DrawSphere(lightPos[0], 0.3f, YELLOW);
                DrawSphere(lightPos[1], 0.3f, BLUE);

            EndMode3D();

            DrawTextureEx(shadowMaps[0].depth, (Vector2){ 10, 520 }, 0.0f, 0.15f, WHITE);
            DrawTextureEx(shadowMaps[1].depth, (Vector2){ 170, 520 }, 0.0f, 0.15f, WHITE);

        EndDrawing();
    }

    UnloadModel(models.plane);
    UnloadModel(models.cube);
    UnloadModel(models.sphere);
    UnloadModel(models.cylinder);
    UnloadShader(casterShader);
    UnloadShader(shadowShader);
    UnloadRenderTexture(shadowMaps[0]);
    UnloadRenderTexture(shadowMaps[1]);
    CloseWindow();

    return 0;
}
