#include "raylib.h"
#include "raymath.h"
#include "rlgl.h"    // Gives access to rlPushMatrix(), rlMultMatrixf(), and rlPopMatrix()
#include <stdlib.h>
#include <math.h>

#define MAX_PARTICLES 4000
#define PARTICLE_RADIUS 0.10f
#define REST_DISTANCE (PARTICLE_RADIUS * 1.8f)
#define PBD_ITERATIONS 3
#define GRAVITY -9.81f

#define GRID_DIM 28
#define CELL_SIZE REST_DISTANCE
#define BOX_SIZE 2.0f

typedef struct {
    Vector3 pos;     // Stored in Local Box Space
    Vector3 oldPos;
    Vector3 vel;
} PBFParticle;

static PBFParticle particles[MAX_PARTICLES];
static int particleCount = 0;

static int gridHead[GRID_DIM * GRID_DIM * GRID_DIM];
static int particleNext[MAX_PARTICLES];

// Container Rotation State
static Vector3 boxRot = { 0.0f, 0.0f, 0.0f };

// Camera Arcball State
static float camDist = 7.5f;
static Vector2 camAngle = { 0.0f, 0.4f };

static inline int LocalToCellIndex(Vector3 pos) {
    int gx = (int)((pos.x + BOX_SIZE) / CELL_SIZE);
    int gy = (int)((pos.y + BOX_SIZE) / CELL_SIZE);
    int gz = (int)((pos.z + BOX_SIZE) / CELL_SIZE);

    if (gx < 0) gx = 0; if (gx >= GRID_DIM) gx = GRID_DIM - 1;
    if (gy < 0) gy = 0; if (gy >= GRID_DIM) gy = GRID_DIM - 1;
    if (gz < 0) gz = 0; if (gz >= GRID_DIM) gz = GRID_DIM - 1;

    return gx + GRID_DIM * (gy + GRID_DIM * gz);
}

void SpawnWater(void) {
    if (particleCount >= MAX_PARTICLES) return;
    for (int i = 0; i < 2; i++) {
        if (particleCount < MAX_PARTICLES) {
            float rx = ((float)rand() / RAND_MAX - 0.5f) * 0.4f;
            float rz = ((float)rand() / RAND_MAX - 0.5f) * 0.4f;
            particles[particleCount].pos = (Vector3){ rx, 1.8f, rz };
            particles[particleCount].oldPos = particles[particleCount].pos;
            particles[particleCount].vel = (Vector3){ 0.0f, -4.0f, 0.0f };
            particleCount++;
        }
    }
}

void UpdatePBF(float dt) {
    float limit = BOX_SIZE - PARTICLE_RADIUS;

    // 1. Transform World Gravity into Local Container Space
    Matrix boxMatrix = MatrixRotateXYZ((Vector3){ DEG2RAD * boxRot.x, DEG2RAD * boxRot.y, DEG2RAD * boxRot.z });
    Matrix invBoxMatrix = MatrixInvert(boxMatrix);
    Vector3 worldGravity = (Vector3){ 0.0f, GRAVITY, 0.0f };
    Vector3 localGravity = Vector3Transform(worldGravity, invBoxMatrix);

    // Predict positions using local gravity
    for (int i = 0; i < particleCount; i++) {
        particles[i].vel = Vector3Add(particles[i].vel, Vector3Scale(localGravity, dt));
        particles[i].oldPos = particles[i].pos;
        particles[i].pos = Vector3Add(particles[i].pos, Vector3Scale(particles[i].vel, dt));
    }

    // 2. Local-Space Spatial Grid PBF Solver
    int totalCells = GRID_DIM * GRID_DIM * GRID_DIM;
    for (int iter = 0; iter < PBD_ITERATIONS; iter++) {
        for (int c = 0; c < totalCells; c++) gridHead[c] = -1;

        for (int i = 0; i < particleCount; i++) {
            int cellIdx = LocalToCellIndex(particles[i].pos);
            particleNext[i] = gridHead[cellIdx];
            gridHead[cellIdx] = i;
        }

        for (int i = 0; i < particleCount; i++) {
            int gx = (int)((particles[i].pos.x + BOX_SIZE) / CELL_SIZE);
            int gy = (int)((particles[i].pos.y + BOX_SIZE) / CELL_SIZE);
            int gz = (int)((particles[i].pos.z + BOX_SIZE) / CELL_SIZE);

            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        int nx = gx + dx, ny = gy + dy, nz = gz + dz;
                        if (nx < 0 || nx >= GRID_DIM || ny < 0 || ny >= GRID_DIM || nz < 0 || nz >= GRID_DIM) continue;

                        int nCell = nx + GRID_DIM * (ny + GRID_DIM * nz);
                        int j = gridHead[nCell];

                        while (j != -1) {
                            if (i < j) {
                                Vector3 delta = Vector3Subtract(particles[i].pos, particles[j].pos);
                                float distSqr = Vector3LengthSqr(delta);

                                if (distSqr < REST_DISTANCE * REST_DISTANCE && distSqr > 0.00001f) {
                                    float dist = sqrtf(distSqr);
                                    Vector3 norm = Vector3Scale(delta, 1.0f / dist);
                                    float deltaP = 0.5f * (REST_DISTANCE - dist);

                                    particles[i].pos = Vector3Add(particles[i].pos, Vector3Scale(norm, deltaP));
                                    particles[j].pos = Vector3Subtract(particles[j].pos, Vector3Scale(norm, deltaP));
                                }
                            }
                            j = particleNext[j];
                        }
                    }
                }
            }
        }

        // Exact Local Boundary Constraints
        for (int i = 0; i < particleCount; i++) {
            if (particles[i].pos.y < -limit) particles[i].pos.y = -limit;
            if (particles[i].pos.y >  limit) particles[i].pos.y =  limit;
            if (particles[i].pos.x < -limit) particles[i].pos.x = -limit;
            if (particles[i].pos.x >  limit) particles[i].pos.x =  limit;
            if (particles[i].pos.z < -limit) particles[i].pos.z = -limit;
            if (particles[i].pos.z >  limit) particles[i].pos.z =  limit;
        }
    }

    // 3. Velocity Update
    for (int i = 0; i < particleCount; i++) {
        particles[i].vel = Vector3Scale(Vector3Subtract(particles[i].pos, particles[i].oldPos), 1.0f / dt);
    }
}

int main(void) {
    InitWindow(1000, 800, "Interactive Rotatable Container Fluid Engine - Raylib");
    SetTargetFPS(60);

    Camera3D camera = { 0 };
    camera.target = (Vector3){ 0.0f, 0.0f, 0.0f };
    camera.up = (Vector3){ 0.0f, 1.0f, 0.0f };
    camera.fovy = 45.0f;
    camera.projection = CAMERA_PERSPECTIVE;

    Mesh sphereMesh = GenMeshSphere(PARTICLE_RADIUS, 8, 8);
    Material sphereMat = LoadMaterialDefault();
    sphereMat.maps[MATERIAL_MAP_DIFFUSE].color = (Color){ 0, 160, 255, 220 };

    while (!WindowShouldClose()) {
        // --- Refined Camera Controls (Right Click Drag + Wheel Zoom) ---
        if (IsMouseButtonDown(MOUSE_BUTTON_RIGHT)) {
            Vector2 mouseDelta = GetMouseDelta();
            camAngle.x -= mouseDelta.x * 0.005f;
            camAngle.y += mouseDelta.y * 0.005f;
            if (camAngle.y > 1.5f) camAngle.y = 1.5f;
            if (camAngle.y < -1.5f) camAngle.y = -1.5f;
        }
        camDist -= GetMouseWheelMove() * 0.5f;
        if (camDist < 3.0f) camDist = 3.0f;
        if (camDist > 16.0f) camDist = 16.0f;

        camera.position.x = camDist * cosf(camAngle.y) * sinf(camAngle.x);
        camera.position.y = camDist * sinf(camAngle.y);
        camera.position.z = camDist * cosf(camAngle.y) * cosf(camAngle.x);

        // --- Box Interaction (Left Click Drag or Arrow Keys) ---
        if (IsMouseButtonDown(MOUSE_BUTTON_LEFT)) {
            Vector2 mouseDelta = GetMouseDelta();
            boxRot.z -= mouseDelta.x * 0.4f;
            boxRot.x += mouseDelta.y * 0.4f;
        }
        if (IsKeyDown(KEY_LEFT))  boxRot.z += 1.5f;
        if (IsKeyDown(KEY_RIGHT)) boxRot.z -= 1.5f;
        if (IsKeyDown(KEY_UP))    boxRot.x -= 1.5f;
        if (IsKeyDown(KEY_DOWN))  boxRot.x += 1.5f;

        if (IsKeyDown(KEY_SPACE)) SpawnWater();
        if (IsKeyPressed(KEY_R)) { particleCount = 0; boxRot = (Vector3){ 0 }; }

        UpdatePBF(0.016f);

        // Precompute render transforms for rotated box & particles
        Matrix boxMatrix = MatrixRotateXYZ((Vector3){ DEG2RAD * boxRot.x, DEG2RAD * boxRot.y, DEG2RAD * boxRot.z });

        BeginDrawing();
            ClearBackground((Color){ 12, 16, 22, 255 });

            BeginMode3D(camera);
                // Draw Rotated Container Box
                rlPushMatrix();
                    rlMultMatrixf(MatrixToFloat(boxMatrix));
                    DrawCubeWires((Vector3){ 0, 0, 0 }, BOX_SIZE * 2, BOX_SIZE * 2, BOX_SIZE * 2, RAYWHITE);
                rlPopMatrix();

                // Render Fluid Particles relative to Box Transform
                for (int i = 0; i < particleCount; i++) {
                    Matrix pTranslate = MatrixTranslate(particles[i].pos.x, particles[i].pos.y, particles[i].pos.z);
                    Matrix worldTransform = MatrixMultiply(pTranslate, boxMatrix);
                    DrawMesh(sphereMesh, sphereMat, worldTransform);
                }
            EndMode3D();

            DrawText("[Left Click + Drag] Tilt Container | [Right Click + Drag] Orbit Camera", 10, 10, 18, RAYWHITE);
            DrawText("[Mouse Wheel] Zoom | [SPACE] Pour Water | [R] Reset", 10, 35, 18, RAYWHITE);
            DrawText(TextFormat("Particles: %d / %d", particleCount, MAX_PARTICLES), 10, 60, 18, SKYBLUE);
            DrawFPS(10, 85);
        EndDrawing();
    }

    UnloadMaterial(sphereMat);
    UnloadMesh(sphereMesh);
    CloseWindow();
    return 0;
}
