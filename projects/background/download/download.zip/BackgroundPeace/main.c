// 1. Rename Windows functions before importing windows.h to prevent Raylib collisions
#define CloseWindow Win32CloseWindow
#define ShowCursor  Win32ShowCursor
#define Rectangle   Win32Rectangle

#define WIN32_LEAN_AND_MEAN
#define NOGDI
#include <windows.h>

// 2. Undefine Windows macros that clash with Raylib function names
#undef CloseWindow
#undef ShowCursor
#undef Rectangle
#undef LoadImage
#undef DrawText
#undef DrawTextEx
#undef PlaySound

// 3. Project Headers
#include "raylib.h"
#include "raymath.h"
#include "rlgl.h"

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MAX_TREES 4
#define MAX_CLOUDS 6
#define MAX_BIRDS 6
#define MAX_WIND_PARTICLES 60

typedef struct {
    float baseX;
    float scaleFactor;
} Tree;

typedef struct {
    Vector2 pos;
    Vector2 vel;
    float scale;
} Cloud;

typedef struct {
    Vector2 pos;
    Vector2 vel;
    bool isHeld;
    float wingAngle;
} Bird;

typedef struct {
    Vector2 pos;
    float speed;
    float length;
    float alpha;
} WindParticle;

typedef struct {
    bool isCovered;
} CoverCheckContext;

// Callback for EnumWindows to locate WorkerW
BOOL CALLBACK EnumWindowsProc(HWND topHandle, LPARAM lparam) {
    HWND shell = FindWindowExA(topHandle, NULL, "SHELLDLL_DefView", NULL);
    if (shell != NULL) {
        *(HWND*)lparam = FindWindowExA(NULL, topHandle, "WorkerW", NULL);
    }
    return TRUE;
}

// Locate WorkerW window behind desktop icons
HWND GetDesktopWorkerW(void) {
    HWND progman = FindWindowA("Progman", NULL);
    SendMessageTimeoutA(progman, 0x052C, 0, 0, SMTO_NORMAL, 1000, NULL);
    
    HWND workerw = NULL;
    EnumWindows(EnumWindowsProc, (LPARAM)&workerw);
    
    return workerw;
}

// Evaluates if a given window covers the monitor screen or work area
bool IsWindowCoveringDesktop(HWND hwnd) {
    if (!IsWindowVisible(hwnd) || IsIconic(hwnd)) return false;

    char className[256];
    if (GetClassNameA(hwnd, className, sizeof(className))) {
        if (strcmp(className, "Progman") == 0 || 
            strcmp(className, "WorkerW") == 0 ||
            strcmp(className, "Shell_TrayWnd") == 0 ||
            strcmp(className, "ImmersiveLauncher") == 0) {
            return false;
        }
    }

    // Direct maximized check
    if (IsZoomed(hwnd)) return true;

    // Check window dimensions against monitor bounds & work area (screen minus taskbar)
    RECT winRect;
    if (GetWindowRect(hwnd, &winRect)) {
        int winWidth = winRect.right - winRect.left;
        int winHeight = winRect.bottom - winRect.top;

        HMONITOR hMon = MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST);
        MONITORINFO mi = { sizeof(MONITORINFO) };
        if (GetMonitorInfoA(hMon, &mi)) {
            int workWidth = mi.rcWork.right - mi.rcWork.left;
            int workHeight = mi.rcWork.bottom - mi.rcWork.top;
            
            int monWidth = mi.rcMonitor.right - mi.rcMonitor.left;
            int monHeight = mi.rcMonitor.bottom - mi.rcMonitor.top;

            // True if window spans full screen OR full work area (maximized)
            if ((winWidth >= workWidth - 12 && winHeight >= workHeight - 12) ||
                (winWidth >= monWidth - 12 && winHeight >= monHeight - 12)) {
                return true;
            }
        }
    }

    return false;
}

BOOL CALLBACK CheckMaximizedProc(HWND hwnd, LPARAM lparam) {
    CoverCheckContext* ctx = (CoverCheckContext*)lparam;
    
    HWND root = GetAncestor(hwnd, GA_ROOT);
    if (!root) root = hwnd;

    if (IsWindowCoveringDesktop(root)) {
        ctx->isCovered = true;
        return FALSE; // Stop enumeration once a covering window is detected
    }
    return TRUE;
}

bool IsScreenCovered(void) {
    // 1. Check Foreground Window first
    HWND fgWindow = GetForegroundWindow();
    if (fgWindow) {
        HWND rootFg = GetAncestor(fgWindow, GA_ROOT);
        if (!rootFg) rootFg = fgWindow;

        char className[256];
        if (GetClassNameA(rootFg, className, sizeof(className))) {
            if (strcmp(className, "Progman") == 0 || 
                strcmp(className, "WorkerW") == 0 || 
                strcmp(className, "Shell_TrayWnd") == 0) {
                return false;
            }
        }

        if (IsWindowCoveringDesktop(rootFg)) {
            return true;
        }
    }

    // 2. Scan open windows to detect any background maximized/fullscreen windows
    CoverCheckContext ctx = { false };
    EnumWindows(CheckMaximizedProc, (LPARAM)&ctx);
    return ctx.isCovered;
}

int main(void) {
    // ------------------------------------------------------------
    // Enable High-DPI Awareness & Calculate Work Area
    // ------------------------------------------------------------
    SetProcessDPIAware();

    RECT workArea;
    SystemParametersInfoA(SPI_GETWORKAREA, 0, &workArea, 0);

    const int startX = workArea.left;
    const int startY = workArea.top;
    const int screenWidth = workArea.right - workArea.left;
    const int screenHeight = workArea.bottom - workArea.top;
    
    const float scale = (float)screenHeight / 900.0f;

    SetConfigFlags(FLAG_WINDOW_UNDECORATED | FLAG_MSAA_4X_HINT);
    InitWindow(screenWidth, screenHeight, "Physics Wallpaper Engine");
    SetWindowPosition(startX, startY);
    SetTargetFPS(60);

    // Attach to Windows WorkerW (Desktop Layer)
    HWND raylibHwnd = (HWND)GetWindowHandle();
    HWND workerw = GetDesktopWorkerW();
    if (workerw) {
        LONG_PTR style = GetWindowLongPtr(raylibHwnd, GWL_STYLE);
        style &= ~WS_POPUP;
        style &= ~WS_CAPTION;
        style |= WS_CHILD;
        SetWindowLongPtr(raylibHwnd, GWL_STYLE, style);

        SetParent(raylibHwnd, workerw);
        SetWindowPos(raylibHwnd, HWND_BOTTOM, startX, startY, screenWidth, screenHeight, SWP_NOACTIVATE | SWP_NOREDRAW);
    }

    // ------------------------------------------------------------
    // Initialize Scene Objects
    // ------------------------------------------------------------
    Tree trees[MAX_TREES] = {
        { screenWidth * 0.12f, 1.0f },
        { screenWidth * 0.35f, 1.25f },
        { screenWidth * 0.68f, 0.95f },
        { screenWidth * 0.88f, 1.15f }
    };

    Cloud clouds[MAX_CLOUDS];
    for (int i = 0; i < MAX_CLOUDS; i++) {
        clouds[i].pos = (Vector2){ (float)(rand() % screenWidth), (float)(80 + rand() % 160) * scale };
        clouds[i].vel = (Vector2){ (0.3f + (rand() % 4) * 0.1f), 0.0f };
        clouds[i].scale = (1.3f + (rand() % 10) * 0.1f) * scale;
    }

    Bird birds[MAX_BIRDS];
    for (int i = 0; i < MAX_BIRDS; i++) {
        birds[i].pos = (Vector2){ (float)(rand() % screenWidth), (float)(100 + rand() % 200) * scale };
        birds[i].vel = (Vector2){ (float)(3 + rand() % 3) * scale, 0.0f };
        birds[i].isHeld = false;
        birds[i].wingAngle = (float)(rand() % 100);
    }

    WindParticle windParticles[MAX_WIND_PARTICLES];
    for (int i = 0; i < MAX_WIND_PARTICLES; i++) {
        windParticles[i].pos = (Vector2){ (float)(rand() % screenWidth), (float)(rand() % (int)(screenHeight - (100 * scale))) };
        windParticles[i].speed = (float)(220 + rand() % 280) * scale;
        windParticles[i].length = (float)(35 + rand() % 55) * scale;
        windParticles[i].alpha = (float)(rand() % 100) / 100.0f;
    }

    float wallpaperTime = 0.0f;
    int heldBirdIndex = -1;

    // ------------------------------------------------------------
    // Main Render Loop
    // ------------------------------------------------------------
    while (!WindowShouldClose()) {
        // Pause execution and bypass graphics rendering when desktop is occluded
        if (IsScreenCovered()) {
            Sleep(100);
            continue;
        }

        float deltaTime = GetFrameTime();
        wallpaperTime += deltaTime;

        Vector2 mousePos = GetMousePosition();
        bool mousePressed = IsMouseButtonPressed(MOUSE_BUTTON_LEFT);
        bool mouseDown = IsMouseButtonDown(MOUSE_BUTTON_LEFT);

        float globalWind = sinf(wallpaperTime * 1.5f) * 0.08f + cosf(wallpaperTime * 2.8f) * 0.04f;

        // Wind Streamers
        for (int i = 0; i < MAX_WIND_PARTICLES; i++) {
            windParticles[i].pos.x += (windParticles[i].speed + fabsf(globalWind) * 200.0f * scale) * deltaTime;
            if (windParticles[i].pos.x > screenWidth + 120 * scale) {
                windParticles[i].pos.x = -120 * scale;
                windParticles[i].pos.y = (float)(rand() % (int)(screenHeight - 150 * scale));
            }
        }

        // Repelling Clouds
        for (int i = 0; i < MAX_CLOUDS; i++) {
            clouds[i].pos.x += clouds[i].vel.x * 60.0f * deltaTime;
            
            float dist = Vector2Distance(mousePos, clouds[i].pos);
            float threshold = 280.0f * scale;
            if (dist < threshold) {
                Vector2 pushDir = Vector2Normalize(Vector2Subtract(clouds[i].pos, mousePos));
                clouds[i].pos = Vector2Add(clouds[i].pos, Vector2Scale(pushDir, (threshold - dist) * 0.12f));
            }

            if (clouds[i].pos.x > screenWidth + 250 * scale) clouds[i].pos.x = -250 * scale;
        }

        // Grabbable Birds
        if (mousePressed && heldBirdIndex == -1) {
            for (int i = 0; i < MAX_BIRDS; i++) {
                if (Vector2Distance(mousePos, birds[i].pos) < 70.0f * scale) {
                    heldBirdIndex = i;
                    birds[i].isHeld = true;
                    break;
                }
            }
        }

        if (mouseDown && heldBirdIndex != -1) {
            Vector2 prevPos = birds[heldBirdIndex].pos;
            birds[heldBirdIndex].pos = mousePos;
            birds[heldBirdIndex].vel = Vector2Scale(Vector2Subtract(mousePos, prevPos), 0.5f);
        } else if (!mouseDown && heldBirdIndex != -1) {
            birds[heldBirdIndex].isHeld = false;
            heldBirdIndex = -1;
        }

        for (int i = 0; i < MAX_BIRDS; i++) {
            if (!birds[i].isHeld) {
                birds[i].pos = Vector2Add(birds[i].pos, birds[i].vel);
                birds[i].wingAngle += 0.25f;

                birds[i].vel.y *= 0.98f;
                if (birds[i].pos.y < 80 * scale) birds[i].vel.y = 1.0f * scale;

                if (birds[i].pos.x > screenWidth + 80 * scale) birds[i].pos.x = -80 * scale;
                if (birds[i].pos.x < -80 * scale) birds[i].pos.x = screenWidth + 80 * scale;
            }
        }

        // ------------------------------------------------------------
        // Draw Frame
        // ------------------------------------------------------------
        BeginDrawing();
            ClearBackground((Color){ 170, 215, 245, 255 });

            // Sun
            Vector2 sunCenter = { screenWidth - (240.0f * scale), 180.0f * scale };
            DrawCircleV(sunCenter, 95.0f * scale, GOLD);
            DrawCircleV(sunCenter, 135.0f * scale, (Color){ 255, 220, 0, 35 });

            // Wind Streamers
            for (int i = 0; i < MAX_WIND_PARTICLES; i++) {
                DrawLineEx(
                    windParticles[i].pos,
                    (Vector2){ windParticles[i].pos.x + windParticles[i].length, windParticles[i].pos.y },
                    2.0f * scale,
                    (Color){ 255, 255, 255, (unsigned char)(windParticles[i].alpha * 140) }
                );
            }

            // Clouds
            for (int i = 0; i < MAX_CLOUDS; i++) {
                float x = clouds[i].pos.x;
                float y = clouds[i].pos.y;
                float s = clouds[i].scale;
                DrawCircle(x, y, 45 * s, WHITE);
                DrawCircle(x + 40 * s, y - 16 * s, 55 * s, WHITE);
                DrawCircle(x + 85 * s, y, 40 * s, WHITE);
            }

            // Ground & Grass
            float groundHeight = 90.0f * scale;
            DrawRectangle(0, screenHeight - groundHeight, screenWidth, groundHeight, (Color){ 50, 110, 55, 255 });
            
            float stepWidth = 16.0f * scale;
            for (float x = 0; x < screenWidth; x += stepWidth) {
                DrawTriangle(
                    (Vector2){ x, (float)screenHeight - groundHeight },
                    (Vector2){ x + (stepWidth * 0.5f), (float)screenHeight - groundHeight - (25.0f * scale) },
                    (Vector2){ x + stepWidth, (float)screenHeight - groundHeight },
                    (Color){ 70, 145, 65, 255 }
                );
            }

            // Pond
            float pondX = screenWidth * 0.5f;
            float pondY = screenHeight - (45.0f * scale);
            DrawEllipse(pondX, pondY, 280 * scale, 45 * scale, (Color){ 40, 120, 200, 255 });
            DrawEllipse(pondX, pondY - (4.0f * scale), 240 * scale, 32 * scale, (Color){ 70, 170, 230, 180 });

            // Evergreen Pine Trees
            for (int t = 0; t < MAX_TREES; t++) {
                float tScale = scale * trees[t].scaleFactor;
                Vector2 treeBase = { trees[t].baseX, (float)screenHeight - groundHeight + (10.0f * scale) };

                float naturalSway = sinf(wallpaperTime * 2.0f + (t * 1.5f)) * globalWind;
                float distToMouse = Vector2Distance(mousePos, treeBase);
                float mouseInfluence = 0.0f;
                if (distToMouse < 320.0f * scale) {
                    float pushDir = (treeBase.x < mousePos.x) ? -1.0f : 1.0f;
                    mouseInfluence = pushDir * ((320.0f * scale - distToMouse) / (320.0f * scale)) * 0.22f;
                }
                float swayAngle = naturalSway + mouseInfluence;

                // Central Wood Trunk
                float trunkWidth = 32.0f * tScale;
                float trunkHeight = 310.0f * tScale;
                
                Rectangle trunkRect = { treeBase.x, treeBase.y, trunkWidth, trunkHeight };
                Vector2 trunkOrigin = { trunkWidth / 2.0f, trunkHeight };
                DrawRectanglePro(trunkRect, trunkOrigin, swayAngle * RAD2DEG, (Color){ 75, 48, 30, 255 });

                // Multi-tiered Pine Foliage
                int tiers = 4;
                for (int i = 0; i < tiers; i++) {
                    float tierProgress = (float)i / (float)tiers;
                    float heightOffset = trunkHeight * (0.35f + tierProgress * 0.68f);
                    
                    Vector2 tierCenter = {
                        treeBase.x + sinf(swayAngle) * heightOffset,
                        treeBase.y - cosf(swayAngle) * heightOffset
                    };

                    float tierWidth = (240.0f - (i * 44.0f)) * tScale;
                    float tierHeight = (130.0f - (i * 20.0f)) * tScale;

                    Vector2 topPoint = {
                        tierCenter.x + sinf(swayAngle) * tierHeight,
                        tierCenter.y - cosf(swayAngle) * tierHeight
                    };

                    Vector2 perp = { cosf(swayAngle), sinf(swayAngle) };
                    Vector2 leftPoint = {
                        tierCenter.x - perp.x * (tierWidth * 0.5f),
                        tierCenter.y - perp.y * (tierWidth * 0.5f)
                    };
                    Vector2 rightPoint = {
                        tierCenter.x + perp.x * (tierWidth * 0.5f),
                        tierCenter.y + perp.y * (tierWidth * 0.5f)
                    };

                    Color pineColor = (i % 2 == 0) ? (Color){ 20, 80, 45, 255 } : (Color){ 30, 105, 55, 255 };
                    DrawTriangle(topPoint, leftPoint, rightPoint, pineColor);
                }
            }

            // Birds
            for (int i = 0; i < MAX_BIRDS; i++) {
                float wingOffset = sinf(birds[i].wingAngle) * (16.0f * scale);
                Vector2 p = birds[i].pos;

                Color birdColor = birds[i].isHeld ? RED : DARKGRAY;
                DrawCircleV(p, 13 * scale, birdColor);
                
                DrawLineEx(p, (Vector2){ p.x - (18 * scale), p.y - wingOffset }, 3.5f * scale, birdColor);
                DrawLineEx(p, (Vector2){ p.x + (18 * scale), p.y - wingOffset }, 3.5f * scale, birdColor);
            }

        EndDrawing();
    }

    CloseWindow();
    return 0;
}
